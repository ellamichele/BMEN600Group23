# Source and reuse notes

Source: Adam Labadorf, Seung H. Choi and Richard H. Myers, "Evidence for a Pan-Neurodegenerative Disease Response in Huntington's and Parkinson's Disease Expression Profiles," Frontiers in Molecular Neuroscience, vol. 10, art. 430, Jan. 11, 2018. https://doi.org/10.3389/fnmol.2017.00430

Repository: https://bitbucket.org/adamlabadorf/hdvpd_mrnaseq/

Fixed commit: `17240f0638045dbc4739472fdb2578276bcfd0d3`.

Accessed and analyzed: 9 October 2026. This is this analysis's access date, not an asserted date for the team's original download.

The repository README states: "This work is licensed under a Creative Commons Attribution-ShareAlike 4.0 International License."

License: https://creativecommons.org/licenses/by-sa/4.0/

Preserve attribution, identify modifications, and retain the ShareAlike terms where applicable when sharing source-derived materials. No additional donor metadata, protected genotypes or raw sequencing files are bundled. Do not attempt donor re-identification.

The supplied text files were matched to all three source CSVs using SHA256 after standardizing line endings and final whitespace. `input_manifest.json` records those hashes. The raw CSV is the primary analysis input. The source already calls it `nonzero`; it is not a FASTQ file or an assurance that no earlier processing occurred.

Changes in this analysis: excluded H-prefixed columns; applied per-sample CPM and log2(CPM+1); filtered CPM >= 1 in at least 16 retained samples; selected 2,000 variable genes for centered PCA; generated new QC tables and figures. Trimmed and normalized matrices were audited but not used to estimate the report PCA.

Important unresolved provenance issue: 50 C-labelled columns in the repository matrices versus 49 controls in the paper. Labels in this preliminary package are prefix-based and provisional. The paper's demographic summaries must not be assigned to the 79-column working subset. No cause for the discrepancy has been established.

The paper describes BA9 prefrontal cortex, not multiple brain regions. GTEx is literature context, not the analyzed data. GSE68719 is a related Parkinson source study; it is not asserted to be a one-to-one identity for the combined repository matrix. The draft's GSE216281 attribution was not established and is not used.
