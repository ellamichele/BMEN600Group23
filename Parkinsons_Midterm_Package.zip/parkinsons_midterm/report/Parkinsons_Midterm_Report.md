Parkinson Disease Signatures in Prefrontal Cortex Gene Expression

BMEN 600 Midterm Research Plan

9 October 2026

Team members

________________________________________________________

________________________________________________________

Project repository

GitHub URL: ______________________________________________

Research scope

A Parkinson disease versus control analysis of public postmortem prefrontal cortex RNA sequencing data, with reproducible preliminary figures and a proposed donor-level machine learning evaluation.


<!-- page break -->

## 1 Introduction and Motivation

Parkinson disease (PD) involves selective loss of vulnerable neuronal populations, while molecular changes can also be measured outside the most severely affected regions. Single-cell profiling has identified a particularly vulnerable dopamine-neuron population in the substantia nigra [1]. Bulk cortical RNA sequencing offers a complementary way to investigate disease-associated expression, although its signals combine changes in gene regulation and tissue composition. Understanding what these measurements can predict, and where their interpretation fails, is relevant to developing reliable computational tools for neurodegeneration research.

Our research question is: How accurately can regularized gene-expression models distinguish PD from neurologically healthy control samples in postmortem prefrontal cortex under donor-level validation? We will estimate discrimination relative to simple baselines and assess the stability of influential genes. The contribution is a reproducible evaluation of this cohort, with explicit controls for overfitting and confounding. The present midterm establishes data feasibility and exploratory structure; predictive performance remains to be evaluated.

## 2 Background and Research Gap

Evidence at different biological scales motivates a cortical study but constrains its interpretation. Kamath et al. used single-nucleus and spatial profiling to identify selective vulnerability within human dopamine neurons [1]. In contrast, Dumitriu et al. combined RNA sequencing and proteomics from prefrontal cortex and implicated mitochondrial and protein-folding processes in PD [2]. Their cross-platform comparison indicates that transcript abundance alone does not capture every protein-level change. A bulk cortical classifier therefore cannot establish the molecular cause of dopamine-neuron loss.

Labadorf et al. reanalyzed cortical expression across PD, Huntington disease and controls and reported shared inflammatory signatures [3]. This supports investigating PD-associated cortical expression, while warning that a signal distinguishing PD from healthy controls need not be specific to PD. We restrict the current comparison to PD and controls. The earlier study tested gene-level associations; our narrower methodological question concerns the performance and stability of a multivariable model evaluated on held-out donors.

Cross-tissue studies address a related but different problem. The GTEx Consortium characterized genetic regulation across many human tissues and emphasized the importance of tissue and cell-type context [4]. Wang et al. showed that cross-tissue correlations and genetic information can support expression imputation in uncollected tissues [5]. The BRONTE preprint integrates GTEx with the Allen Brain Atlas to impute expression in additional brain tissues [6]. Its retrieved version is explicitly a preprint. These approaches motivated the original regional-transfer idea, but the current dataset has one cortical region and cannot estimate transferability between regions.

Methodological literature further narrows the feasible analysis. DESeq2 models RNA-seq counts with dispersion estimation, supporting an appropriate count-based approach to differential expression [7]. Ambroise and McLachlan demonstrated that selecting genes before validation can bias prediction estimates [8]. Consequently, our proposed classifier will repeat feature selection within training folds and report uncertainty. We do not claim a new PD biomarker or an unexplored biological mechanism; the manageable gap is whether a small, high-dimensional cortical cohort supports reproducible discrimination after these safeguards.


<!-- page break -->

## 3 Dataset and Responsible Use

The analyzed data are three gene-by-sample CSV matrices from the public hdvpd_mrnaseq repository associated with Labadorf et al. [3], [9]. The source study describes postmortem prefrontal cortex Brodmann area 9 and poly-A-selected mRNA sequencing. For this analysis, the files were accessed on 9 October 2026 at repository commit 17240f0638045dbc4739472fdb2578276bcfd0d3. Downloaded files matched the provided copies after line-ending normalization. They are not GTEx matrices. The related PD transcriptomic/proteomic study is described in [2].

Each row is an Ensembl gene identifier; each sample column contains gene-level expression counts. The independent unit should be a brain donor, not a gene or a value in the matrix. Until an authoritative donor map is recovered, the present outputs describe sample columns. C_, P_ and H_ prefixes are treated as provisional control, Parkinson and Huntington labels. All 29 H_ columns are excluded before normalization, filtering or PCA. The working analysis includes 50 C_ and 29 P_ columns.

Table 1. Audit of the supplied matrices. All three share the same 108 sample identifiers. Only the raw-count version is used for the main figures.

| Representation | Gene rows | C_ / P_ / H_ | Use |
| --- | --- | --- | --- |
| Raw counts | 27,282 | 50 / 29 / 29 | Primary input |
| Trimmed raw counts | 21,179 | 50 / 29 / 29 | Provenance audit |
| Normalized trimmed counts | 21,179 | 50 / 29 / 29 | Provenance audit |

The matrices contain no missing numeric entries or duplicate gene identifiers. The trimmed file differs from the corresponding raw values in 1,461 cells across 1,136 genes; it is not simply a row subset. Starting from the raw-count version keeps the current transformation explicit, although this repository file has already undergone upstream processing. Count totals refer only to genes in the supplied matrix, not total sequencing reads.

A material discrepancy remains: the publication reports 49 controls [3], whereas the matrices contain 50 C_-labelled columns. We retain all 50 provisionally for the descriptive audit and will reconcile sample identifiers, diagnoses, exclusions and donor uniqueness before supervised modelling. Demographic summaries from the publication will not be assigned to this subset. Age, sex, ancestry, RNA integrity, postmortem interval, disease severity, medication exposure and sequencing batch are absent from the pasted matrices. The earlier PD study describes male tissue donors [2], which raises a representation concern; exact composition of this combined subset requires metadata verification.

The repository README declares a Creative Commons Attribution-ShareAlike 4.0 license [9]. Shared source-derived materials will retain attribution and the applicable license terms, with analysis changes documented. The reproducibility package downloads inputs from their source rather than redistributing sequencing data. Coded identifiers reduce direct identification but do not guarantee anonymity, so no donor re-identification or linkage to identifiable records will be attempted. Postmortem sampling, unequal group sizes and potentially restricted demographic coverage limit generalization to living patients and broader populations.


<!-- page break -->

## 4 Proposed Methods and Evaluation

The completed preprocessing provides a descriptive progress check. We remove H_-labelled columns, verify nonnegative integer input and nonzero sample totals, and compute counts per million (CPM) separately within each retained sample. Genes are retained at CPM >= 1 in at least 20% of the 79 columns, rounded up to 16 samples. Expression is transformed as log2(CPM + 1). For exploratory PCA, we select the 2,000 genes with highest sample variance, center each gene and use singular value decomposition without variance scaling. No diagnosis labels enter gene selection. Because this PCA uses the full working cohort, it is not an estimate of predictive performance.

The supervised analysis will begin only after the sample map and exclusions are resolved. The target will be PD status; predictors will be gene expression. An L2-regularized logistic regression will provide a tractable first model for a dataset with many more genes than donors. The final pipeline will compute per-sample CPM, learn the expression filter within each training fold, apply log2(CPM + 1), select the 500 most variable eligible genes, standardize using training-set means and standard deviations, and fit the classifier. Selection of 500 genes is prespecified; alternative feature counts will be sensitivity analyses rather than choices based on outer-test performance.

We will use five-fold outer cross-validation repeated with five fixed seeds. Each repeat will yield one held-out prediction per donor. A three-fold inner split will select inverse regularization strength C from {0.01, 0.1, 1, 10} using ROC area under the curve (ROC-AUC). Splits will be stratified by diagnosis and grouped by donor; repeated samples from a donor will remain together in every inner and outer split. Class weights will be balanced. Every learned transformation, including covariate adjustment if used, will be fitted only on training data. The all-cohort PCA and any all-cohort differential-expression gene list will not supply features for model evaluation [8].

The primary result will be held-out ROC-AUC, supplemented by balanced accuracy, sensitivity, specificity and a confusion matrix at a prespecified probability threshold of 0.5. A constant-probability model and an always-control classifier will provide reference performance. For the present 50:29 working split, always predicting control gives 63.3% accuracy but 50% balanced accuracy and zero PD sensitivity. These analytical baselines are not fitted classifier results. Once metadata are available, we will compare expression-only and covariate-only models, and assess whether expression adds information beyond age, RNA integrity, postmortem interval and batch.

We will report the range of scores across outer repeats rather than treating dependent folds as independent replicates. A donor-level bootstrap of averaged out-of-fold probabilities will supply an approximate 95% interval, explicitly conditional on this dataset and fitted validation procedure. At least 200 label permutations will rerun the complete nested pipeline, respecting donor groups and feasible exchangeability blocks. If batch and diagnosis are inseparable, disease-specific prediction will be considered unidentifiable in this cohort. Stable coefficient directions and gene-selection frequencies will guide cautious biological interpretation; they will not establish causality.

Python, NumPy, pandas and Matplotlib implement the current audit and figures. The delivered download script verifies fixed-version inputs, and the analysis script exports graphs and numerical tables. The Colab notebook runs both steps. A later scikit-learn modelling module will implement the nested pipeline. Any differential-expression extension will use a count-appropriate method such as DESeq2 [7] with verified covariates and false-discovery control, separate from predictive feature selection.


<!-- page break -->

## 5 Preliminary Results

The first result is a feasible but provisional PD-versus-control cohort. Figure 1 shows the 79 included sample columns. Huntington-labelled columns are omitted entirely. The imbalance makes accuracy alone unsuitable for evaluating the planned model. Metadata reconciliation is needed before interpreting these column counts as verified independent donors.

![Figure 1](../results/figure_1_cohort.png)

Figure 1. Included sample columns: 50 control-labelled (63.3%) and 29 Parkinson-labelled (36.7%). Labels are inferred from the source identifiers; the extra control relative to the published cohort remains unresolved.

![Figure 2](../results/figure_2_quality.png)

Figure 2. Quality-control summaries before expression filtering. Each dot is one of the 79 included columns. Boxes show the median and interquartile range; whiskers extend to observations within 1.5 interquartile ranges. A: total counts across the 27,282 supplied genes. B: genes with at least one count. All observations are shown as jittered points; jitter seed is 600.

Count totals span 6.15 to 63.39 million, a 10.3-fold range. Detected genes range from 18,068 to 22,501. This motivates explicit normalization and inspection of unusual samples, without automatically deleting low-count observations. These are expression-matrix checks; read mapping, RNA integrity and other sequencing-quality measures cannot be reconstructed from them.


<!-- page break -->

## 5 Preliminary Results Continued

![Figure 3](../results/figure_3_pca.png)

Figure 3. Descriptive PCA of 79 samples using the 2,000 highest-variance genes among 16,102 filtered genes. Input is log2(CPM + 1), centered per gene and not variance-scaled. PC1 explains 45.3% and PC2 14.2% of variance within this selected feature set. Colors and shapes identify provisional diagnosis groups; the PCA itself is label-blind.

Within the PD/control subset, 287 genes have zero counts in every sample. The prespecified CPM filter retains 16,102 genes. Figure 3 reveals broad expression variation with substantial overlap between the groups and several samples far from the main concentration. The first two components together explain 59.5% of the variance in the selected genes, not 59.5% of disease status or whole-transcriptome variation. Visible differences in group distribution suggest a testable classification question, but do not establish its predictive accuracy or biological specificity.

The audit changed the project scope. A cross-region transferability matrix would require matched observations from multiple regions, which these files do not provide. The revised study instead asks whether PD-associated cortical expression supports discrimination among donors. It can realistically provide descriptive evidence and an internally validated estimate within a small postmortem cohort. It cannot establish regional vulnerability, early diagnosis, a causal disease mechanism or generalization to an independent clinical population.

The main remaining uncertainty is the sample-level metadata: the extra control label, donor independence and confounding must be resolved. Subsequent work will inspect the extreme PCA observations against available technical variables, document exclusions without consulting model performance, complete nested validation and examine sensitivity to filtering and normalization choices. An independent cohort with comparable tissue and processing would be required for external validation. If usable metadata cannot be recovered, the defensible final scope is an explicitly unadjusted descriptive analysis with restricted conclusions.


<!-- page break -->

## 6 Teamwork and Project Plan

The team will work through the milestones below after the 16 October midterm deadline. Dates are relative because the final submission date must be aligned with the course schedule. Owner fields and the contribution table are intentionally blank for the team to complete.

| Milestone | Deliverable | Owner |
| --- | --- | --- |
| Week 1 after midterm | Reconcile 50 versus 49 controls; verify labels, donors, covariates and exclusions. |  |
| Week 2 | Implement and review nested modelling and baseline comparisons. |  |
| Week 3 | Run uncertainty, permutation and confounding sensitivity analyses. |  |
| Final week | Review biological interpretation, rerun notebook, finalize report and repository. |  |

## Data and Code Availability

The dataset source is the Labadorf repository [9]. The local reproducibility package contains a README, pinned software requirements, input hashes, Python scripts, a self-contained Colab notebook, and generated figures and tables. Data access instructions preserve the original source and license. No raw sequencing files or restricted donor records are redistributed. The project GitHub URL must be inserted below after the team uploads and checks its repository.

Project GitHub URL: ______________________________________________

## AI Assisted Work

OpenAI Codex assisted with checking the draft against the dataset structure, locating scholarly sources, writing Python code, generating figures and drafting this report. The executed analysis checked matrix dimensions, values, identifiers and transformations, and source downloads were compared with the supplied copies using normalized-text hashes. References were checked against publisher, PubMed/PMC or repository records. Team members must independently rerun the Colab notebook, verify the sources and numerical outputs, and review the scientific claims before submission; no completed human verification is asserted here.

## Author Contributions

Complete the table with actual work, including research-question development, literature review, data preparation, code, analysis, figures, interpretation, writing, revision and verification.

| Team member | Contributions completed | Verification and review completed |
| --- | --- | --- |
|  |  |  |
|  |  |  |
|  |  |  |
|  |  |  |


<!-- page break -->

## References

[1] T. Kamath et al., "Single-cell genomic profiling of human dopamine neurons identifies a population that selectively degenerates in Parkinson's disease," Nature Neuroscience, vol. 25, pp. 588-595, 2022. doi: 10.1038/s41593-022-01061-1. [Source](https://doi.org/10.1038/s41593-022-01061-1)

[2] A. Dumitriu et al., "Integrative analyses of proteomics and RNA transcriptomics implicate mitochondrial processes, protein folding pathways and GWAS loci in Parkinson disease," BMC Medical Genomics, vol. 9, art. 5, 2016. doi: 10.1186/s12920-016-0164-y. [Source](https://doi.org/10.1186/s12920-016-0164-y)

[3] A. Labadorf, S. H. Choi, and R. H. Myers, "Evidence for a Pan-Neurodegenerative Disease Response in Huntington's and Parkinson's Disease Expression Profiles," Frontiers in Molecular Neuroscience, vol. 10, art. 430, Jan. 2018. doi: 10.3389/fnmol.2017.00430. [Source](https://doi.org/10.3389/fnmol.2017.00430)

[4] The GTEx Consortium, "The GTEx Consortium atlas of genetic regulatory effects across human tissues," Science, vol. 369, no. 6509, pp. 1318-1330, 2020. doi: 10.1126/science.aaz1776. [Source](https://doi.org/10.1126/science.aaz1776)

[5] J. Wang et al., "Imputing Gene Expression in Uncollected Tissues Within and Beyond GTEx," American Journal of Human Genetics, vol. 98, no. 4, pp. 697-708, 2016. doi: 10.1016/j.ajhg.2016.02.020. [Source](https://doi.org/10.1016/j.ajhg.2016.02.020)

[6] J. Ke, T. Ge, and R. D. Melamed, "Discovering disease genetic variation impacting gene expression in 103 brain tissues with the Brain Ontology Expression (BRONTE) graph neural network model," bioRxiv, preprint, version 1, May 14, 2025. doi: 10.1101/2025.05.08.652857. [Source](https://doi.org/10.1101/2025.05.08.652857)

[7] M. I. Love, W. Huber, and S. Anders, "Moderated estimation of fold change and dispersion for RNA-seq data with DESeq2," Genome Biology, vol. 15, art. 550, 2014. doi: 10.1186/s13059-014-0550-8. [Source](https://doi.org/10.1186/s13059-014-0550-8)

[8] C. Ambroise and G. J. McLachlan, "Selection bias in gene extraction on the basis of microarray gene-expression data," Proceedings of the National Academy of Sciences, vol. 99, no. 10, pp. 6562-6566, 2002. doi: 10.1073/pnas.102102699. [Source](https://doi.org/10.1073/pnas.102102699)

[9] A. Labadorf, "Source code for HD vs PD mRNA-Seq analysis," Bitbucket repository, commit 17240f0638045dbc4739472fdb2578276bcfd0d3. Accessed: Oct. 9, 2026. [Online]. Available: https://bitbucket.org/adamlabadorf/hdvpd_mrnaseq/. Repository README specifies CC BY-SA 4.0. [Source](https://bitbucket.org/adamlabadorf/hdvpd_mrnaseq/src/17240f0638045dbc4739472fdb2578276bcfd0d3/)
