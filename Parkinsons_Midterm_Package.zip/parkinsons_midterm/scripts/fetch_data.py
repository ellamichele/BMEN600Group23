"""Download fixed-version public inputs, preserving source attribution.

Source: Labadorf, Choi and Myers, Front. Mol. Neurosci. 10:430 (2018).
Repository README declares CC BY-SA 4.0. See SOURCE_AND_LICENSE.md.
"""
from pathlib import Path
import argparse
import hashlib
import json
import urllib.request

COMMIT = '17240f0638045dbc4739472fdb2578276bcfd0d3'
BASE = f'https://api.bitbucket.org/2.0/repositories/adamlabadorf/hdvpd_mrnaseq/src/{COMMIT}/'
FILES = ['all_mRNA_nonzero_raw_counts.csv', 'all_mRNA_nonzero_raw_counts_trim.csv',
         'all_mRNA_nonzero_norm_counts_trim.csv']

def canonical_hash(path):
    # Pasted files have Windows line endings; source CSV has Unix line endings.
    text = Path(path).read_text(encoding='utf-8-sig').replace('\r\n','\n').strip()+'\n'
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def fetch(destination='data', all_versions=True, manifest=None):
    destination = Path(destination)
    destination.mkdir(parents=True,exist_ok=True)
    expected = json.loads(Path(manifest).read_text()) if manifest else {}
    for name in FILES if all_versions else FILES[:1]:
        target = destination/name
        if not target.exists():
            request = urllib.request.Request(BASE+name,headers={'User-Agent':'BMEN600-reproducibility/1.0'})
            with urllib.request.urlopen(request,timeout=180) as response:
                target.write_bytes(response.read())
        digest = canonical_hash(target)
        if name in expected and digest != expected[name]['canonical_sha256']:
            raise ValueError(f'{name}: input differs from the report dataset; do not reuse reported numbers.')
        print(f'{name}: verified canonical SHA256 {digest}')
    return destination

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',default='data')
    p.add_argument('--raw-only',action='store_true')
    p.add_argument('--manifest',default=None)
    a=p.parse_args()
    fetch(a.out,not a.raw_only,a.manifest)
