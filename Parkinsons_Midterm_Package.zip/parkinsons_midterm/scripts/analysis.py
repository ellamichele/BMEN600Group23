"""Reproduce the BMEN 600 Parkinson's/control preliminary figures.

No clinical classifier is fitted here. All graphs are descriptive. Huntington's
columns are excluded before filtering, normalization and PCA.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import platform
import importlib.metadata
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

COLORS = {'Control': '#26778C', 'Parkinson': '#BE623F'}
NAMES = {'Control': 'Control', 'Parkinson': "Parkinson's"}

def read_counts(path):
    with open(path, encoding='utf-8-sig', newline='') as handle:
        header = next(csv.reader(handle))
    if len(header) != len(set(header)):
        raise ValueError('Duplicate column names in input.')
    frame = pd.read_csv(path, index_col=0)
    if frame.index.has_duplicates or frame.index.isna().any():
        raise ValueError('Missing or duplicate gene identifiers.')
    values = frame.to_numpy(dtype=float)
    if not np.isfinite(values).all() or (values < 0).any():
        raise ValueError('Counts must be finite and nonnegative.')
    if not all(str(c).startswith(('C_', 'P_', 'H_')) for c in frame.columns):
        raise ValueError('Unexpected sample prefix; supply and verify a sample map.')
    return frame

def save_figure(fig, out, name):
    for ext in ('png', 'pdf'):
        fig.savefig(out / f'{name}.{ext}', dpi=220, bbox_inches='tight')
    plt.close(fig)

def run(raw_path, out_dir='results', normalized_path=None, trimmed_path=None):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                         'axes.spines.top': False, 'axes.spines.right': False,
                         'axes.titleweight': 'bold', 'savefig.facecolor': 'white'})
    raw = read_counts(raw_path)
    if not np.equal(raw.values, np.round(raw.values)).all():
        raise ValueError('Primary input must contain unnormalized integer counts.')
    selected = raw.loc[:, raw.columns.str.startswith(('C_', 'P_'))]
    group = np.where(selected.columns.str.startswith('P_'), 'Parkinson', 'Control')
    if set(group) != {'Control', 'Parkinson'}:
        raise ValueError('Both P_ and C_ samples are required.')
    n = len(group)
    totals = selected.sum(axis=0)
    if (totals <= 0).any():
        raise ValueError('A sample has zero total counts.')
    # Counts per million use all supplied genes before filtering; this is not TPM.
    cpm = selected.divide(totals, axis=1) * 1e6
    minimum_samples = int(np.ceil(0.20 * n))
    keep = (cpm >= 1).sum(axis=1) >= minimum_samples
    log_cpm = np.log2(cpm.loc[keep] + 1)
    # Label-blind descriptive PCA: 2,000 most variable filtered genes, no scaling.
    variances = log_cpm.var(axis=1, ddof=1)
    chosen = variances.sort_values(ascending=False, kind='stable').head(2000).index
    matrix = log_cpm.loc[chosen].T.to_numpy()
    centered = matrix - matrix.mean(axis=0)
    u, singular, vt = np.linalg.svd(centered, full_matrices=False)
    # Fix SVD sign ambiguity so reruns produce matching graph orientation.
    for component in range(2):
        pivot = np.argmax(np.abs(vt[component]))
        if vt[component, pivot] < 0:
            u[:, component] *= -1
            vt[component] *= -1
    scores = u[:, :2] * singular[:2]
    explained = singular[:2] ** 2 / np.sum(singular ** 2)
    qc = pd.DataFrame({'sample_id': selected.columns, 'group': group,
         'total_counts_in_supplied_matrix': totals.values,
         'detected_genes_gt_zero': (selected > 0).sum(axis=0).values,
         'zero_fraction': (selected == 0).mean(axis=0).values,
         'PC1': scores[:, 0], 'PC2': scores[:, 1]})
    qc.to_csv(out / 'sample_qc_and_pca.csv', index=False)
    pd.Series(chosen, name='ENSG').to_csv(out / 'pca_gene_ids.csv', index=False)
    pd.Series(log_cpm.index, name='ENSG').to_csv(out / 'filtered_gene_ids.csv', index=False)
    summary = {'raw_gene_rows': int(raw.shape[0]), 'all_sample_columns': int(raw.shape[1]),
        'control_n': int((group == 'Control').sum()), 'parkinson_n': int((group == 'Parkinson').sum()),
        'excluded_huntington_columns': int(raw.columns.str.startswith('H_').sum()),
        'analysis_n': n, 'missing_values': int(raw.isna().sum().sum()),
        'duplicate_gene_ids': int(raw.index.duplicated().sum()),
        'all_zero_genes_in_pd_control': int((selected == 0).all(axis=1).sum()),
        'filter_min_samples': minimum_samples, 'filtered_gene_rows': int(keep.sum()),
        'pca_gene_rows': len(chosen), 'pca_variance_ratio': explained.tolist(),
        'majority_accuracy': float((group == 'Control').mean()),
        'count_total_min': int(totals.min()), 'count_total_max': int(totals.max()),
        'count_total_ratio': float(totals.max()/totals.min()),
        'detected_gene_min': int(qc.detected_genes_gt_zero.min()),
        'detected_gene_max': int(qc.detected_genes_gt_zero.max()),
        'python_version': platform.python_version(),
        'versions': {p: importlib.metadata.version(p) for p in ['numpy','pandas','matplotlib']},
        'input_sha256': hashlib.sha256(Path(raw_path).read_bytes()).hexdigest(),
        'caveat': '50 C-labelled columns versus 49 controls in the 2018 paper; metadata reconciliation pending.'}
    audit = []
    for label, path in [('Raw', raw_path), ('Trimmed', trimmed_path), ('Normalized trimmed', normalized_path)]:
        if path:
            frame = read_counts(path)
            audit.append({'version': label, 'genes': len(frame), 'samples': frame.shape[1],
                'C': int(frame.columns.str.startswith('C_').sum()),
                'P': int(frame.columns.str.startswith('P_').sum()),
                'H': int(frame.columns.str.startswith('H_').sum()),
                'missing_values': int(frame.isna().sum().sum()),
                'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest()})
            if label == 'Trimmed':
                aligned = raw.loc[frame.index, frame.columns]
                summary['trimmed_values_different_from_raw'] = int((aligned.values != frame.values).sum())
                summary['trimmed_genes_different_from_raw'] = int((aligned.values != frame.values).any(axis=1).sum())
    pd.DataFrame(audit).to_csv(out / 'input_audit.csv', index=False)
    (out / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    fig, ax = plt.subplots(figsize=(6.6, 3.1))
    counts = [summary['control_n'], summary['parkinson_n']]
    bars = ax.bar(['Control', "Parkinson's"], counts, color=list(COLORS.values()), width=.55)
    for bar, number in zip(bars, counts):
        ax.text(bar.get_x()+bar.get_width()/2, number+.8, f'{number} ({number/n:.1%})', ha='center')
    ax.set(ylim=(0,max(counts)*1.23), ylabel='Sample columns', title='Parkinson and control analysis cohort')
    fig.tight_layout()
    save_figure(fig, out, 'figure_1_cohort')
    fig, axes = plt.subplots(1, 2, figsize=(9.6, 3.6))
    rng = np.random.default_rng(600)
    for ax, column, scale, ylabel, title in [
        (axes[0], 'total_counts_in_supplied_matrix',1e6,'Total supplied counts (millions)','A  Count totals'),
        (axes[1], 'detected_genes_gt_zero',1e3,'Genes with counts > 0 (thousands)','B  Detected genes')]:
        values = [qc.loc[qc.group==g,column].to_numpy()/scale for g in COLORS]
        ax.boxplot(values, positions=[0,1], widths=.4, showfliers=False,
                   medianprops={'color':'black'}, patch_artist=False)
        for pos, (g, v) in enumerate(zip(COLORS, values)):
            ax.scatter(pos+rng.uniform(-.12,.12,len(v)), v, s=21, alpha=.75, color=COLORS[g], zorder=3)
        ax.set_xticks([0,1], ['Control', "Parkinson's"])
        ax.set(ylabel=ylabel,title=title)
    fig.tight_layout(w_pad=2)
    save_figure(fig, out, 'figure_2_quality')
    fig, ax = plt.subplots(figsize=(7.4,4.5))
    for g, color in COLORS.items():
        mask = group == g
        ax.scatter(scores[mask,0],scores[mask,1],s=38,color=color,alpha=.83,
                   marker='o' if g=='Control' else '^', label=f'{NAMES[g]} (n={mask.sum()})')
    ax.set(xlabel=f'PC1 ({explained[0]:.1%} of selected-gene variance)',
           ylabel=f'PC2 ({explained[1]:.1%})', title='Exploratory expression structure')
    ax.axhline(0,color='#D9D9D9',lw=.7,zorder=0)
    ax.axvline(0,color='#D9D9D9',lw=.7,zorder=0)
    ax.legend(frameon=False)
    fig.tight_layout()
    save_figure(fig, out, 'figure_3_pca')
    print(json.dumps(summary,indent=2))
    return summary

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw',required=True)
    parser.add_argument('--trimmed')
    parser.add_argument('--normalized')
    parser.add_argument('--out',default='results')
    args=parser.parse_args()
    run(args.raw,args.out,args.normalized,args.trimmed)
