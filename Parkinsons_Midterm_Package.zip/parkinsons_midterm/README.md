# Parkinson disease cortical transcriptomics

BMEN 600 midterm research plan, prepared 9 October 2026.

Research question: How accurately can regularized gene-expression models distinguish Parkinson disease from neurologically healthy control samples in postmortem prefrontal cortex under donor-level validation?

## Start in Google Colab

1. Open https://colab.research.google.com/ and choose **File > Upload notebook**.
2. Upload `Parkinsons_Midterm_Colab.ipynb` from this package.
3. Choose **Runtime > Run all**. A standard CPU runtime is sufficient; no GPU is needed.
4. The notebook installs the analysis packages, downloads the three public source CSVs at a fixed commit, checks their hashes, excludes all `H_` columns, and reproduces the three report figures. No Google Drive connection is needed.
5. The last cell downloads a ZIP containing the figures, sample-level QC/PCA coordinates, input audit, and numerical summary.

The notebook is self-contained: its analysis and download code are included in cells. You do not need to upload the separate scripts or the large datasets. Network access to PyPI and Bitbucket is required. If Bitbucket is unavailable, use the notebook's optional upload cell with the original three files renamed as listed below, then rerun the analysis cell. Never substitute normalized counts for raw counts.

## Files

- `report/Parkinsons_Midterm_Report.pdf`: report with six body pages plus title and references.
- `report/Parkinsons_Midterm_Report.md`: editable report text.
- `Parkinsons_Midterm_Colab.ipynb`: self-contained Colab notebook.
- `scripts/fetch_data.py`: fixed-commit download and input checks.
- `scripts/analysis.py`: data audit, normalization, filtering, PCA, graphs and tables.
- `results/figure_1_cohort.png`: sample counts.
- `results/figure_2_quality.png`: supplied count totals and detected genes.
- `results/figure_3_pca.png`: descriptive PCA; no classifier has been evaluated.
- `results/summary.json`: machine-readable numerical results and package versions.
- `results/sample_qc_and_pca.csv`: one row per retained sample column.
- `results/input_audit.csv`: dimensions and byte-level hashes of the analyzed inputs.
- `input_manifest.json`: line-ending-independent source hashes.
- `SOURCE_AND_LICENSE.md`: provenance, upstream license and interpretation limits.

## Run locally

Python 3.12 was used for the tested run. From the package folder:

```bash
python -m pip install -r requirements.txt
python scripts/fetch_data.py --out data --manifest input_manifest.json
python scripts/analysis.py --raw data/all_mRNA_nonzero_raw_counts.csv --trimmed data/all_mRNA_nonzero_raw_counts_trim.csv --normalized data/all_mRNA_nonzero_norm_counts_trim.csv --out results
```

Primary file: `all_mRNA_nonzero_raw_counts.csv` (27,282 genes x 108 columns).
Other files: `all_mRNA_nonzero_raw_counts_trim.csv` and `all_mRNA_nonzero_norm_counts_trim.csv` (each 21,179 genes x 108 columns). They are alternative representations, not independent cohorts. Files are never concatenated.

## Analysis choices

Exclude Huntington (`H_`) before computing anything about the analysis cohort. Treat `C_` as provisional control labels and `P_` as Parkinson labels. Divide each sample's supplied counts by its total and multiply by one million (CPM). Keep genes with CPM >= 1 in at least 20% of the 79 samples, i.e. 16 samples. Apply log2(CPM + 1). Select the 2,000 highest-variance genes without diagnosis labels and perform centered, unscaled PCA by SVD. This whole-cohort PCA is descriptive and must not be reused as preprocessing for held-out model evaluation. PCA signs are fixed by each component's largest loading. Jitter seed is 600.

## Before submission and supervised modelling

The paper reports 49 controls, whereas these source matrices have 50 C-labelled columns. Do not guess which column to drop. Reconcile each sample with original metadata and record exclusions. Confirm one independent donor per column; recover age, sex, RNA integrity, postmortem interval and batch. The present figures describe the 79-column working dataset. They do not establish disease-specific effects or clinical diagnostic performance.

The report proposes a regularized classifier with nested validation; those results have not been invented or presented as completed. All learned model preprocessing must be fitted inside training folds. The current deliverable satisfies the midterm's requirement for a working descriptive analysis, not the final modelling milestone.

Fill in the blank team names/contribution table and GitHub link in the report. Upload the code, notebook, README and appropriate outputs to your chosen repository, then check its access permissions and link. No repository has been created or published by this package. Do not claim team verification until team members have rerun and reviewed the analysis.

## Data source

https://bitbucket.org/adamlabadorf/hdvpd_mrnaseq/src/17240f0638045dbc4739472fdb2578276bcfd0d3/

Labadorf, Choi and Myers (2018), https://doi.org/10.3389/fnmol.2017.00430

The notebook retrieves data directly; source matrices are not bundled in the distributable ZIP. Preserve upstream attribution and CC BY-SA 4.0 terms for reused material.
